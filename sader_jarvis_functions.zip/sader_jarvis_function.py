import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
#import access2thematrix
from scipy.special import hyp2f1 as Fy
import seaborn as sns
sns.set() # Setting seaborn as default style even if use only matplotlib

#from pandas import read_csv
#from scipy.optimize import curve_fit
#from matplotlib import pyplot
#import glob
#import os
#import math


# Force calculation:

############### specification: ##################
'''
It receives two panda data frames with the following columns: 

INPUT: (2 data frames + 3 float numbers). 

df_ON["deltaF", "Z"] - it is assumed that z(i) is closer to the surface than z(i+1) in meters | z(i) < z(i+1)
If this condition is not met we get errors (sqrt or negative numbers). 
df_OFF["deltaF", "Z"]

a: is the amplitude in m
f0: is resonance frequency in Hz
k: is the stiffness of the cantilever in N/m

OUTPUT: [5 numpy arrays]

force: force in N 
delta_f: that's result of df_ON - df_OFF
z: distance in m (same size as force).
omega = delta_f/f0 
dz_omega = derivative of omega (calculated by element wise ratio of diff omega and diff z)

References:

[1] J. E. Sader and S. P. Jarvis
       "Accurate formulas for interaction force and energy 
       in frequency modulation force spectroscopy"
       Applied Physics Letters, 84, 1801-1803 (2004)  
       
[2] Joachim Welker, Esther Illek and Franz J. Giessibl:
        Analysis of force-deconvolution methods in frequency-modulation atomic force microscopy
        https://www.beilstein-journals.org/bjnano/articles/3/27#E7
        In particular equations 10, 12 and 13. 

'''



def sjarvis_deconvolution(df_ON, df_OFF,A,f0,k):

    #For now it assumes that Z are the same for ON and OFF. Later will implement an interpolation on the OFF curve and use that.
    #if df_ON["Z"] == df_OFF["Z"]:

    # 1) calculate df (difference between two data frames).
    # transform into numpy arrays as it's easier to work with them like this inside the function.
    delta_f = df_ON["deltaF"].to_numpy() - df_OFF["deltaF"].to_numpy()
    z = df_ON["Z"].to_numpy()

    # 2) Calculates reduced frequency shift omega = delta_f/f_0.

    omega = delta_f/f0

    # 3) Derivative of the reduced frequency shift dz_omega

    dz_omega = np.ediff1d(omega)/np.ediff1d(z)

    # 4) Because we are umbral/discrete "world" we must adjust the size of Z, omega and delta_f to be the same as dz_omega

    z = z[:-1]
    delta_f = delta_f[:-1]
    omega = omega[:-1]

    # 5) Main loop.

    #Initiate force array
    force = np.zeros(len(z)-1)

    for j in range(len(z)-1):
    # 5a) Adjust length to the size of t.
        t = z[j+1:] # this is due to a pole at t = z
        omega_temp = omega[j+1:]
        dz_omega_temp = dz_omega[j+1:]

    # 5b) calculate integral Eq.(9) in [1] using the trapezoidal method.
        integral = np.trapz(y= (1+np.sqrt(A)/(8*np.sqrt(np.pi*(t -z[j]))))*omega_temp - A**(3/2)/np.sqrt(2*(t-z[j]))*dz_omega_temp,x=t)

    # 5c) corrections for t=z C(j) #All corrections are already divided automatically by f0 since Im using the corrected omega (delta_f/f0)
        correction1 = omega[j]*(z[j+1]-z[j])
        correction2 = 2*(np.sqrt(A)/(8*np.sqrt(np.pi)))*(omega[j]*np.sqrt(z[j+1] - z[j]))
        correction3 = (-np.sqrt(2))*(A**(3/2))*(dz_omega[j]*np.sqrt(z[j+1]-z[j]))
    # 6) F(i) = 2*k*(correction1 + correction2 + correction3 + integral)
        force[j] = 2*k*(correction1+correction2+correction3+integral)

#7) adjust z to be the same size as F

    z = z[:len(force)]

# else:
#     break
#     #ValueError('the Z values of the off curve are not the same as the on, fix this first!.')
    return force, delta_f, omega, dz_omega, z


def fit_lennard_jones():
    pass

def sjarvis_benchmark(zmin=0.23E-9,zmax=5.000E-9,points =5000, sigma = 0.235E-9,E = 0.371E-18,f0 = 32768,k = 1800,A =11.8E-12, simple=False, plot=True):

    if simple==False:

        # BENCHMARK Lennard Jones using Hyper-geometric function
        z = np.linspace(zmin, zmax, num=points)
        # Using Lenard Jones Potential - Fy is that fancy function - check equation 10 of the paper [2].
        pre_factor = -12*f0*E/(sigma*k*A)

        df_on = pre_factor*(((sigma / z)**(7)) * (Fy(7, 0.5, 1, (-2 * A / z)) - Fy(7, 1.5, 2, (-2 * A / z))))
        df_off = pre_factor*(((sigma / z)**(13))*(Fy(13, 0.5, 1, (-2 * A / z)) - Fy(13,1.5,2,(-2 * A / z) )))

        ON = pd.DataFrame({'deltaF': df_on, 'Z': z})
        OFF = pd.DataFrame({'deltaF': df_off, 'Z': z})

    elif simple==True:
        # BENCHMARK Lennard Jones using simple approximation
        z = np.linspace(zmin, zmax, num=points)
        pre_factor = -12*f0*E/(sigma*k*A)
        df_on = pre_factor*((sigma / z)**(8))
        df_off = pre_factor*((sigma / z)**(14))
        ON = pd.DataFrame({'deltaF': df_on, 'Z': z})
        OFF = pd.DataFrame({'deltaF': df_off, 'Z': z})


    force, delta_f, omega, dz_omega, z_force = sjarvis_deconvolution(df_ON=ON, df_OFF=OFF, A=A, f0=f0, k=k)

    # Plotting stuff.
    cmap = sns.light_palette("#77DD77", as_cmap=True)

    # create a line plot for the mapping function
    # Initialise the subplot function using number of rows and columns

    if plot==True:
        figure, axis = plt.subplots(1,2, figsize=(15, 5), sharex=True)
        sns.lineplot(ax = axis[0],x=z_force, y=force*10**9, color='#ff6969')
        axis[0].set_title("Force vs Z")
        axis[0].set_xlabel("Z[m]")
        axis[0].set_ylabel("Force [nN]")
        axis[0].text(x=0,y=0,s=f"Min Force {np.round(np.min(force)*10**9,2)} nN")

        sns.lineplot(ax = axis[1],x=z_force, y=delta_f[:-1])
        axis[1].set_title("deltaF vs Z")
        axis[1].set_xlabel("Z[m]")
        axis[1].set_ylabel("Df [Hz]")

        plt.show()

    else:
        pass
    min_force = np.min(force)
    return min_force


# CALLING THE FUNCTION.
#sjarvis_benchmark(zmin=0.22E-9,A=10E-12,simple=False)

a_range = np.arange(0.01E-9,1.0E-9,0.01E-9)

min_force= np.zeros(len(a_range))
for i,a in enumerate(a_range):
    min_force[i] = sjarvis_benchmark(zmin=0.23E-9, A=a, simple=False, plot=False)
    print(f"Min force {np.round(min_force[i]*10**9,2)} with a = {a}")
print(np.min(min_force))
#force, delta_f, omega, dz_omega, z_force = sjarvis_deconvolution(df_ON=ON,df_OFF=OFF,A=A,f0=f0,k=k)
